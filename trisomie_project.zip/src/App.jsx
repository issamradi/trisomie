import { useState } from "react";

const TOPICS = [
  {
    id: "t21", label: "Trisomie 21", accent: "#0F6E56", light: "#E1F5EE", border: "#5DCAA5",
    questions: [
      { q: "La trisomie 21 est :", opts: ["A. Due à une carence en acide folique avant la conception", "B. Une anomalie chromosomique constitutionnelle déséquilibrée", "C. La plus fréquente des anomalies chromosomiques", "D. La première cause des retards mentaux", "E. Liée à l'âge des grands parents"], ans: ["B","C","D"] },
      { q: "Les signes cliniques retrouvés dans la trisomie 21 néonatale sont :", opts: ["A. Une Hypertonie", "B. Une hyperlaxité ligamentaire", "C. Un livédo", "D. Un diastasis des muscles droits de l'abdomen", "E. Une hernie ombilicale"], ans: ["B","C","D","E"] },
      { q: "Dans la trisomie 21, quelles sont les malformations et les complications à rechercher systématiquement en période néonatale ?", opts: ["A. Les malformations cardiaques", "B. Les malformations digestives", "C. La cataracte congénitale", "D. La surdité congénitale", "E. Le diabète"], ans: ["A","B","C","D"] },
      { q: "Au premier trimestre de la grossesse, le calcul de risque d'une trisomie 21 tient compte de plusieurs éléments, lesquels ?", opts: ["A. Le triple test", "B. L'âge de la mère", "C. La mesure de la clarté nucale", "D. Le dosage de la fraction β libre HCG", "E. Le dosage de la PAPP-A"], ans: ["B","C","D","E"] },
      { q: "Dans la trisomie 21, la ségrégation alterne selon le mode 2:1 d'une translocation (14:21) produit :", opts: ["A. 2 gamètes équilibrés", "B. Un gamète Normal et un gamète transloqué (dérivé)", "C. 4 gamètes déséquilibrés", "D. 4 gamètes déséquilibrés et 2 gamètes équilibrés", "E. 6 gamètes déséquilibrés"], ans: ["B"] },
      { q: "(Cas clinique – 15 SA) Les signes cliniques qui peuvent être retrouvés dans la trisomie 21 prénatale sont :", opts: ["A. Un hygroma", "B. Une longueur du fémur inférieure à -1DS", "C. Une dolichocéphalie", "D. Une syndactylie des 2ème et 3ème orteils", "E. Une hernie ombilicale"], ans: ["A","B","D","E"] },
      { q: "Les signes biologiques indiquant une trisomie 21 prénatale sont :", opts: ["A. Une augmentation de la fraction β libre de l'HCG", "B. Une diminution de l'alpha fœtoprotéine (AFP)", "C. Une augmentation de l'œstriol non conjugué (uE3)", "D. Une augmentation de la PAPP-A", "E. Une augmentation de la progestérone"], ans: ["A","B"] },
      { q: "Le calcul de risque de survenue de la trisomie 21 tient compte de plusieurs éléments, lesquels ?", opts: ["A. L'âge de la mère", "B. Les malformations associées", "C. La mesure de la clarté nucale", "D. Le taux de la fraction β libre HCG", "E. Le taux de la progestérone"], ans: ["A","C","D"] },
      { q: "Les complications qui peuvent être rencontrées dans la trisomie 21 sont :", opts: ["A. Les infections à répétitions", "B. La leucémie chronique", "C. L'hypothyroïdie", "D. L'épilepsie", "E. La surdité"], ans: ["A","C","D","E"] },
      { q: "La surveillance annuelle d'un enfant de 6 ans atteint de trisomie 21 comporte :", opts: ["A. Une échographie cardiaque même en l'absence de symptomatologie", "B. La recherche systématique de la maladie cœliaque", "C. Un examen ORL", "D. Une radiographie de l'atlas et l'axis", "E. Le dosage de T4 et TSH"], ans: ["C","D","E"] },
      { q: "Les signes dysmorphiques retrouvés dans la trisomie 21 sont :", opts: ["A. L'épicanthus", "B. L'hyperplasie des os propres du nez", "C. Le pli palmaire transversal unique", "D. La brachymésophalangie du 3ème doigt", "E. Les fentes palpébrales obliques en haut et en dehors"], ans: ["A","C","E"] },
      { q: "Les marqueurs sériques utilisés dans le diagnostic prénatal de la trisomie 21 sont :", opts: ["A. La Fraction β libre de l'HCG", "B. La Protéine plasmatique placentaire de type A (PAPPA)", "C. L'alpha fœtoprotéine (AFP)", "D. L'œstriol non conjugué (uE3)", "E. La progestérone"], ans: ["A","B","C","D"] },
      { q: "Le risque de récurrence de la trisomie 21 chez un couple avec un enfant ayant le caryotype 47,XX,+21 est de :", opts: ["A. 0%", "B. 1%", "C. 25%", "D. 15%", "E. 20%"], ans: ["B"] },
      { q: "Le dépistage néonatal non invasif de la trisomie 21 par l'analyse de l'ADN fœtal est réalisé par :", opts: ["A. Amniocentèse", "B. Biopsie du trophoblaste", "C. Prise de sang chez la future mère", "D. Repérage échographique", "E. Prélèvement du sang du cordon"], ans: ["C"] },
      { q: "Parmi les formules chromosomiques suivantes, quelles sont celles qui correspondent à une trisomie 21 ?", opts: ["A. 46,XY,der(21;22)+21", "B. 45,XY,der(21;22)", "C. 46,XX,t(15;21)+21", "D. 46,XX/47,XX,+21", "E. 47,XX,t(15;21)+21"], ans: ["A","C","D"] },
      { q: "La surveillance annuelle d'un enfant de 3 ans atteint de trisomie 21 comporte :", opts: ["A. Une échographie cardiaque même en l'absence de symptomatologie", "B. La recherche de la maladie cœliaque même en l'absence de symptomatologie", "C. Une radiographie de l'atlas et l'axis", "D. Un examen ophtalmologique", "E. Le dosage de T4 et TSH"], ans: ["D","E"] },
      { q: "Quelles sont les formules chromosomiques de la trisomie 21 dues à une translocation robertsonienne ?", opts: ["A. 46,XY,der(14;21),+21", "B. 45,XY,t(21;21)", "C. 47,XX,+21", "D. 46,XY,t(15;21),+21", "E. 46,XY,rob(15;21),+21"], ans: ["A","D","E"] },
      { q: "Les complications rencontrées dans la trisomie 21 sont :", opts: ["A. Le diabète", "B. L'hyperthyroïdie", "C. La cataracte sénile", "D. La surdité", "E. Les syndromes myélodysplasiques"], ans: ["A","C","D"] },
      { q: "Dans la trisomie 21, l'amniocentèse est proposée lorsque :", opts: ["A. Le triple test montre un risque ≥ 1/250", "B. Il y a des antécédents antérieurs d'anomalies chromosomiques dans la descendance", "C. L'un des parents est porteur d'anomalies chromosomiques équilibrées", "D. Il y a absence de signes échographiques au premier trimestre", "E. L'âge maternel est supérieur à 36 ans"], ans: ["A","B","C"] },
      { q: "Le risque de récurrence d'une trisomie 21 par t(21;21) est de :", opts: ["A. 0%", "B. 25%", "C. 50%", "D. 75%", "E. 100%"], ans: ["E"] },
      { q: "Dans la trisomie 21, le retard mental :", opts: ["A. Associe des difficultés de langage", "B. S'établit rapidement", "C. est de QI 50 à l'âge de cinq ans", "D. Décroît après l'âge de cinq ans", "E. S'associe à des troubles du comportement"], ans: ["A","B","C","D"] },
      { q: "Au Maroc l'incidence de la trisomie 21 est distribuée en 2 pics, lesquels ?", opts: ["A. Un premier pic lié à l'âge maternel", "B. Un premier pic lié à une natalité élevée", "C. Un premier pic lié à l'âge paternel", "D. Un deuxième pic lié à l'âge maternel", "E. Un deuxième pic lié à une natalité élevée"], ans: ["A","E"] },
      { q: "Toutes ces anomalies sont observées dans la trisomie 21 sauf une, laquelle ?", opts: ["A. Épicanthus", "B. Hyperplasie des os propres du nez", "C. Hypotonie", "D. Faciès plat", "E. Clinodactylie du 5ème doigt"], ans: ["B"] },
      { q: "À propos de la trisomie 21, quelle est la formule chromosomique nécessitant la réalisation du caryotype constitutionnel des parents ?", opts: ["A. 47XY+21", "B. 47XY+21/46", "C. 46XX t(14;21)21", "D. 46XX+21", "E. 47XX+21/46"], ans: ["C"] },
      { q: "Quel est le risque d'avoir un enfant atteint de trisomie 21 chez un parent ayant une translocation (21;21) équilibrée ?", opts: ["A. 50%", "B. 75%", "C. 25%", "D. 1%", "E. 100%"], ans: ["E"] },
      { q: "Dans la trisomie 21, le diagnostic prénatal est indiqué devant :", opts: ["A. ATCD familiaux de trisomie 21", "B. Âge maternel inférieur à 38 ans", "C. Marqueurs sériques maternels > 1/250", "D. Présence d'hygroma", "E. Présence de malformation cardiaque"], ans: ["A","C","D","E"] },
      { q: "Les complications rencontrées dans la trisomie 21 sont :", opts: ["A. Les infections", "B. L'absence du langage", "C. L'hypothyroïdie", "D. La cataracte", "E. La surdité"], ans: ["A","C","D","E"] },
      { q: "À propos de la trisomie 21, quelles sont les 2 formules chromosomiques nécessitant la réalisation du caryotype constitutionnel des parents ?", opts: ["A. 47XY+21", "B. 46XY/47XY21", "C. 46XXt(14;21)21", "D. 46XXder(21;21)21", "E. 46XX/47XX21"], ans: ["C","D"] },
      { q: "(Cas clinique – translocation 14:21 transmise par la mère) Quels sont les signes de dysmorphie faciale qui peuvent être observés ?", opts: ["A. L'épicanthus", "B. Les taches de Brushfield", "C. Le faciès allongé", "D. L'hypoplasie des os propres du nez", "E. L'hyportélorisme"], ans: ["A","B","D"] },
      { q: "Cette famille désire d'autres enfants, quel est le risque d'avoir un autre enfant atteint de trisomie 21 (mère porteuse t(14;21)) ?", opts: ["A. 0%", "B. 1%", "C. 20%", "D. 25%", "E. 100%"], ans: ["C"] },
      { q: "Quels sont les indications du diagnostic prénatal de la trisomie 21 ?", opts: ["A. La présence de translocation parentale", "B. L'âge maternel supérieur à 38 ans", "C. La présence d'anomalies échographiques", "D. Le taux de Marqueurs sériques maternels (triple test) inférieur à 1/250", "E. Le taux de Marqueurs sériques maternels (triple test) supérieur à 1/250"], ans: ["A","B","C","E"] },
      { q: "(Cas clinique – translocation 21:21 transmise par le père) Toutes ces anomalies peuvent être observées dans la trisomie 21 sauf une, laquelle ?", opts: ["A. Épicanthus", "B. Taches de Brushfield", "C. Hyper laxité ligamentaire", "D. Hypertonie", "E. Clinodactylie du 5ème doigt"], ans: ["D"] },
      { q: "Les examens complémentaires à demander sont :", opts: ["A. Une échographie cardiaque", "B. Une échographie abdominale", "C. Une NFS", "D. Une TDM cérébrale", "E. Un dosage de T4 TSH"], ans: ["A","B","C","E"] },
      { q: "Quelle est la formule chromosomique du père du garçon trisomique 21 (translocation 21;21) ?", opts: ["A. 46XY", "B. 46XY†(21;21)", "C. 46XY†(21;21)", "D. 45XY+(21;21)", "E. 45XY(21;21)"], ans: ["D"] },
      { q: "Quelle est la formule chromosomique du garçon trisomique 21 (translocation 21;21) ?", opts: ["A. 46,XY", "B. 46,XY,t(21;21)", "C. 46,XY,t(21;21)+21", "D. 45,XY,t(21;21)", "E. 45,XY,t(21;21),+21"], ans: ["C"] },
      { q: "Cette famille désire avoir d'autres enfants, quel est le risque d'avoir un autre enfant atteint de trisomie 21 (père porteur t(21;21)) ?", opts: ["A. 0%", "B. 1%", "C. 25%", "D. 50%", "E. 100%"], ans: ["E"] },
      { q: "Au Maroc la trisomie 21 :", opts: ["A. Est la plus fréquente des anomalies chromosomiques", "B. Est la première cause des retards mentaux", "C. Touche plus les filles que les garçons", "D. A une incidence qui varie avec l'âge de la mère", "E. A une incidence qui varie avec l'âge du père"], ans: ["A","B","D"] },
      { q: "Les signes dysmorphiques retrouvés dans la trisomie 21 sont :", opts: ["A. Un pli palmaire unique", "B. Une clinodactylie du 5ème doigt", "C. Une nuque aplatie avec excès de peau", "D. Une microglossie", "E. Des tâches de Brushfield"], ans: ["A","B","C","E"] },
      { q: "Les malformations viscérales qui peuvent être retrouvées dans la trisomie 21 sont :", opts: ["A. Un méningiome cérébral", "B. Une sténose duodénale", "C. Une persistance du canal artériel", "D. Une cataracte", "E. Une luxation congénitale de la hanche"], ans: ["B","C","D"] },
      { q: "Les complications qui peuvent être rencontrées dans la trisomie 21 sont :", opts: ["A. La surdité", "B. Le diabète", "C. L'hypothyroïdie", "D. La leucémie aiguë", "E. L'occlusion intestinale"], ans: ["A","C","D"] },
      { q: "Le caryotype d'une femme est : 45XX t(21;21). Quel est son risque d'avoir un enfant avec caryotype normal ?", opts: ["A. 0", "B. 1/3", "C. 1/6", "D. 1/2", "E. 1/100"], ans: ["A"] },
      { q: "La mère âgée de 27 ans d'un trisomique 21 ayant un caryotype 47 XX+21. Le risque qu'elle a d'avoir un autre enfant trisomique 21 est de :", opts: ["A. 0", "B. 1/3", "C. 1/6", "D. 1/2", "E. 1%"], ans: ["E"] },
      { q: "Les indications d'un diagnostic prénatal dans la trisomie 21 sont :", opts: ["A. Un couple ayant un enfant porteur d'une trisomie 21", "B. Âge maternel supérieur à 38 ans", "C. Marqueurs sériques maternels < 1/250", "D. Présence d'hygroma", "E. Aucune réponse n'est juste"], ans: ["A","B","D"] },
      { q: "(Cas clinique nouveau-né) À l'examen clinique, les signes de dysmorphie faciale peuvent être présents SAUF un :", opts: ["A. Des fentes palpébrales obliques en haut et en dehors", "B. Une hyperplasie des os propres du nez", "C. Une Brachymésophalangie du 5ème doigt", "D. Une nuque aplatie avec excès de peau", "E. Un pli palmaire unique"], ans: ["B"] },
      { q: "Quels sont les 2 signes d'examen clinique à rechercher en priorité ?", opts: ["A. Les tâches de Brushfield", "B. Le souffle cardiaque", "C. L'hyperlaxité ligamentaire", "D. L'hypotonie", "E. L'épicanthus"], ans: ["B","D"] },
      { q: "Quels sont les examens complémentaires que vous allez demander ?", opts: ["A. Une TDM cérébrale", "B. Une échographie cardiaque", "C. Une échographie abdominale", "D. Le dosage de T3 TSH", "E. Une radiographie des os longs"], ans: ["B","C","D"] },
      { q: "Après la réalisation des examens complémentaires, plusieurs malformations peuvent être retrouvées, lesquelles ?", opts: ["A. Un canal atrio-ventriculaire", "B. Une sténose duodénale", "C. Une cataracte congénitale", "D. Une surdité", "E. Une hypoplasie de la verge"], ans: ["A","B","C","D"] },
      { q: "La formule 46XY+21 correspond à une forme de trisomie 21 :", opts: ["A. Libre et homogène", "B. En mosaïque", "C. Par duplication", "D. Par translocation robertsonienne", "E. Aucune réponse n'est juste"], ans: ["D"] },
      { q: "Un caryotype des parents a montré chez le père la formule chromosomique : 45 XY (sans précision). Il est :", opts: ["A. Trisomique 21", "B. Trisomique 14", "C. Porteur sain", "D. Monosomique 14", "E. Monosomique 21"], ans: ["C"] },
      { q: "Le risque dans cette famille d'avoir un autre enfant ayant une trisomie 21 est de :", opts: ["A. 0% (aucun risque)", "B. 1%", "C. 5%", "D. 50%", "E. 100%"], ans: ["C"] },
      { q: "La fréquence de la trisomie 21 parmi les nouveau-nés est maintenant bien connue, elle est de :", opts: ["A. 1/8000", "B. 1/4000", "C. 1/2000", "D. 1/120", "E. 1/700"], ans: ["E"] },
      { q: "Quels sont les signes cliniques de dysmorphie faciale retrouvés dans la trisomie 21 ?", opts: ["A. Épicanthus", "B. Hypoplasie des os propres du nez", "C. Brachymésophalangie du 5ème doigt", "D. Hypolaxité ligamentaire", "E. Hypotélorisme"], ans: ["A","B","C"] },
      { q: "Quels sont les malformations viscérales rencontrées dans la trisomie 21 ?", opts: ["A. Rein en fer à cheval", "B. Atrésie pulmonaire", "C. Œil en cyclope", "D. Cataracte congénitale", "E. Canal atrio-ventriculaire"], ans: ["D","E"] },
      { q: "Les complications pouvant engager le pronostic vital dans la trisomie 21 sont :", opts: ["A. La leucémie myéloïde chronique", "B. Les fractures spontanées", "C. Le diabète", "D. L'infarctus du myocarde", "E. L'épilepsie"], ans: ["D","E"] },
      { q: "Dans la trisomie 21, la forme cytogénétique « libre et homogène » est retrouvée dans :", opts: ["A. 95% des cas", "B. 75% des cas", "C. 50% des cas", "D. 3% des cas", "E. 2% des cas"], ans: ["A"] },
      { q: "Les mécanismes cytogénétiques expliquant la survenue de la trisomie 21 en mosaïque sont :", opts: ["A. Les accidents mitotiques post-zygotiques", "B. Les accidents méiotiques", "C. La réduction de trisomie 21 présente au stade zygotique", "D. L'anomalie de ségrégation des chromosomes par non-disjonction méiotique", "E. Les translocations réciproques"], ans: ["A","C"] },
      { q: "Le caryotype d'une femme ayant un frère trisomique 21 est : 45XX t(14;21). Le risque qu'elle a d'avoir un enfant avec caryotype normal est de :", opts: ["A. 0", "B. 1/3", "C. 1/6", "D. 1/2", "E. 1/100"], ans: ["C"] },
      { q: "Les indications d'un diagnostic prénatal dans la trisomie 21 sont :", opts: ["A. Un couple ayant un enfant porteur d'une trisomie 21", "B. L'âge maternel supérieur à 34 ans", "C. Les marqueurs sériques maternels < 1/250", "D. L'épaisseur de la nuque supérieure à 3 mm", "E. La présence d'hygroma"], ans: ["A","D","E"] },
      { q: "Au Maroc la répartition de la trisomie 21 en fonction de l'âge maternel suit une courbe avec 2 pics liés à :", opts: ["A. La natalité maximum", "B. L'âge avancé", "C. Le niveau socio-économique", "D. L'état de vaccination", "E. L'origine ethnique"], ans: ["A","B"] },
      { q: "(Cas clinique nouveau-né Al) Quels sont les signes de dysmorphie faciale ?", opts: ["A. Des fentes palpébrales obliques en bas et en dehors", "B. Une hyperplasie des os propres du nez", "C. Une Brachymésophalangie du 5ème doigt", "D. Une nuque aplatie avec excès de peau", "E. Un pli palmaire unique"], ans: ["C","D","E"] },
      { q: "(Cas clinique nouveau-né Al) Quels sont les 2 signes d'examen clinique à rechercher en priorité ?", opts: ["A. Les tâches de Brushfield", "B. Le souffle cardiaque", "C. Le pli palmaire unique", "D. L'hypotonie", "E. L'hyper laxité ligamentaire"], ans: ["B","D"] },
      { q: "(Cas clinique nouveau-né Al) Quels sont les examens complémentaires à demander ?", opts: ["A. Une échographie cardiaque", "B. Une échographie abdominale", "C. Dosage de T3 T4 TSH", "D. Une ponction lombaire", "E. Une TDM cérébrale"], ans: ["A","B","C"] },
      { q: "Le mécanisme pouvant expliquer le phénotype de trisomie 21 avec duplication de la région 21q22 :", opts: ["A. La consanguinité", "B. L'âge maternel avancé", "C. Une prise médicamenteuse au cours de la grossesse", "D. L'effet de l'épigénétique", "E. L'effet de dosage génique"], ans: ["E"] },
      { q: "Dans cette famille, quel est le risque d'avoir un autre enfant atteint de trisomie 21 (parents caryotype normal, enfant T21 par duplication) ?", opts: ["A. 0%", "B. 50%", "C. 1%", "D. 100%", "E. 25%"], ans: ["C"] },
      { q: "À propos de la trisomie 21, quelles sont les 2 formules chromosomiques nécessitant la réalisation du caryotype constitutionnel des parents ?", opts: ["A. 47XY,+21", "B. 47XY,+21/46,XY", "C. 46XX t(14;21)+21", "D. 46XXi(21)(q10)", "E. 47XX,+21/46,XX"], ans: ["C","D"] },
      { q: "Quel est le risque d'avoir un enfant atteint de trisomie 21 chez un parent ayant une translocation (21;21) équilibrée ?", opts: ["A. 1/6", "B. 1/3", "C. 1/2", "D. 1%", "E. 100%"], ans: ["E"] },
      { q: "Dans la trisomie 21, le diagnostic prénatal est indiqué devant :", opts: ["A. Âge paternel supérieur à 60 ans", "B. Âge maternel supérieur à 38 ans", "C. Marqueurs sériques maternels > 1/250", "D. Présence d'une CIV", "E. Présence d'hygroma"], ans: ["B","C","D","E"] },
      { q: "Au Maroc l'incidence de la trisomie 21 :", opts: ["A. Augmente avec l'âge paternel", "B. Est de 1/700", "C. Varie avec l'âge maternel", "D. Est distribuée en 2 pics", "E. Diminue avec l'apport en vitamines"], ans: ["B","C","D"] },
      { q: "Toutes ces anomalies sont observées dans la trisomie 21 sauf une, laquelle ?", opts: ["A. Épicanthus", "B. Taches de Brushfield", "C. Hypertonie", "D. Hyper laxité ligamentaire", "E. Clinodactylie du 5ème doigt"], ans: ["C"] },
      { q: "La sœur d'un trisomique 21 a un caryotype 45 XX t(14;21). Le risque qu'elle a d'avoir un enfant trisomique 21 est :", opts: ["A. 0", "B. 1/3", "C. 1/6", "D. 1/2", "E. 1%"], ans: ["C"] },
      { q: "Le caryotype 48 XXY+21 correspond à un sujet :", opts: ["A. Masculin avec phénotype normal", "B. Masculin avec aspect androïde", "C. Féminin de grande taille avec hyperpilosité", "D. Masculin de grande taille avec hyperpilosité", "E. Masculin avec dysmorphie et retard mental"], ans: ["B"] },
    ]
  },
  {
    id: "t9", label: "Trisomie 8/9", accent: "#854F0B", light: "#FAEEDA", border: "#EF9F27",
    questions: [
      { q: "Dans la trisomie 8 en mosaïque :", opts: ["A. Les garçons sont plus atteints que les filles", "B. Les malformations osseuses sont rares", "C. La déficience intellectuelle est présente", "D. Le déficit intellectuel dépend du pourcentage de cellules trisomiques", "E. Le risque de récurrence est très faible"], ans: ["A","C","E"] },
      { q: "Dans la trisomie 8, quelles sont les propositions justes ?", opts: ["A. Le conseil génétique est rassurant", "B. La dysmorphie faciale est caractéristique", "C. La déficience intellectuelle est proportionnelle au pourcentage des cellules trisomiques", "D. Le tableau clinique comporte des malformations de l'appareil squelettique et osseux", "E. La déficience intellectuelle est très profonde"], ans: ["A","D"] },
      { q: "Dans la trisomie 8 :", opts: ["A. La dysmorphie faciale est caractéristique", "B. La déficience intellectuelle est proportionnelle au pourcentage des cellules trisomiques", "C. Le tableau clinique comporte des malformations de l'appareil squelettique et osseux", "D. Le conseil génétique est rassurant", "E. Aucune réponse n'est juste"], ans: ["C","D"] },
      { q: "À propos de la trisomie 9, quelles sont les propositions justes ?", opts: ["A. Elle est viable lorsqu'elle est libre et homogène", "B. Elle est viable lorsqu'elle est en mosaïque", "C. Le tableau clinique comporte des anomalies de la face", "D. Le tableau clinique comporte des malformations de l'appareil squelettique et osseux", "E. Le signe clinique pathognomonique est la présence d'un œil en cyclope"], ans: ["B","C","D"] },
      { q: "À propos de la trisomie 8, quelles sont les propositions justes ?", opts: ["A. Elle est viable lorsqu'elle est en mosaïque", "B. Le tableau clinique comporte des anomalies de la face", "C. Le tableau clinique comporte des malformations de l'appareil squelettique et osseux", "D. Le signe clinique pathognomonique est la présence d'un œil en cyclope", "E. Le poids à la naissance est habituellement normal"], ans: ["A","C","E"] },
    ]
  },
  {
    id: "t13", label: "Trisomie 13", accent: "#993C1D", light: "#FAECE7", border: "#F0997B",
    questions: [
      { q: "Les signes cliniques ci-dessous peuvent être présents dans la trisomie 13 SAUF un, lequel ?", opts: ["A. Une holoproencéphalie", "B. Un hypotélorisme", "C. Une dolichocéphalie", "D. Une fente labio-palatine", "E. Une hexadactylie"], ans: ["C"] },
      { q: "L'âge maternel élevé est un facteur de risque des maladies chromosomiques suivantes :", opts: ["A. La trisomie 9 en mosaïque", "B. La trisomie X", "C. La trisomie 13", "D. La trisomie 18", "E. Le syndrome de Turner"], ans: ["A","B","C","D"] },
      { q: "Les signes cliniques retrouvés dans la trisomie 13 sont :", opts: ["A. Un épicanthus", "B. Des fentes palpébrales anti-mongoloïdes", "C. Une fente labio-palatine", "D. Une anophtalmie", "E. Un hypertélorisme"], ans: ["C","D"] },
      { q: "Les signes cliniques ci-dessous peuvent être présents dans la trisomie 13 SAUF un, lequel ?", opts: ["A. Une holoproencéphalie", "B. Un hypotélorisme", "C. Une dolichocéphalie", "D. Une fente labio-palatine", "E. Une hexadactylie"], ans: ["C"] },
      { q: "(Cas clinique – biopsie villosités choriales) Ce dépistage prénatal :", opts: ["A. Est réalisé sans consentement écrit", "B. Est réalisé entre 10 et 12 semaines d'aménorrhée", "C. Est réalisé uniquement par voie trans-cervicale", "D. Doit être réalisé sur 2 prélèvements indépendants", "E. Permet de faire un examen cytogénétique direct rapide"], ans: ["B"] },
      { q: "Toutes ces anomalies sont rencontrées dans la trisomie 13 SAUF une, laquelle ?", opts: ["A. L'holoproencéphalie", "B. L'hypertélorisme", "C. La fente labio-palatine", "D. L'hydronéphrose", "E. L'hexadactylie"], ans: ["B"] },
      { q: "Toutes ces anomalies sont observées dans la trisomie 13 SAUF une, laquelle ?", opts: ["A. Hypotélorisme", "B. Fente labio-palatine", "C. Hexadactylie", "D. Hypertonie", "E. Omphalocèle"], ans: ["D"] },
      { q: "Dans la trisomie 13 :", opts: ["A. Le risque augmente avec l'âge maternel", "B. Les malformations viscérales entraînent le décès durant les trois premiers mois de vie", "C. L'holoproencéphalie est présente", "D. Le risque de récurrence est faible", "E. Le diagnostic prénatal est impossible"], ans: ["A","B","C"] },
      { q: "Dans la trisomie 13, quelle est la formule chromosomique nécessitant la réalisation du caryotype constitutionnel des parents ?", opts: ["A. 47,XY,+13", "B. 47,XY,+13/46,XY", "C. 47,XX,+13", "D. 46,XX,i(13)q(10)", "E. 47,XX,+13/46,XX"], ans: ["D"] },
      { q: "Les signes cliniques retrouvés dans la trisomie 13 sont :", opts: ["A. Des pieds bots", "B. Une hexadactylie", "C. Un œil en cyclope", "D. Un hypertélorisme", "E. Une fente labio-palatine"], ans: ["B","C","E"] },
      { q: "Dans la trisomie 13 :", opts: ["A. Le risque de l'avoir augmente avec l'âge maternel", "B. 80% des fœtus atteints de trisomie 13 décèdent in utero", "C. Le risque de récurrence est faible", "D. La prise en charge médicale est limitée aux soins de support et de confort", "E. Le traitement chirurgical des malformations modifie le pronostic"], ans: ["A","B","D"] },
      { q: "À propos de la trisomie 13, quelles sont les propositions FAUSSES ?", opts: ["A. Le risque de récurrence est très augmenté", "B. Le tableau clinique comporte un syndrome malformatif léger", "C. La survie moyenne est au-delà de 2 ans", "D. Le risque augmente avec l'âge maternel", "E. Le risque augmente avec l'âge paternel"], ans: ["B","C","E"] },
      { q: "À propos de la trisomie 13, quelles sont les propositions justes ?", opts: ["A. Le caryotype des parents doit être réalisé quel que soit la formule chromosomique de l'enfant", "B. Le tableau clinique inclut un syndrome dysmorphique et malformatif grave", "C. 90% des fœtus atteints de trisomie 13 décèdent in utero", "D. Son risque augmente avec l'âge maternel", "E. Son risque de récurrence est faible"], ans: ["B","C","D"] },
      { q: "Dans la trisomie 13 :", opts: ["A. La majorité des fœtus décèdent in utéro", "B. Le risque de survenue dépend de l'âge maternel", "C. La dysmorphie se caractérise par la griffe digitale", "D. La dysmorphie se caractérise par le pied en piolet", "E. Aucune réponse n'est juste"], ans: ["A","B"] },
      { q: "La trisomie 13 :", opts: ["A. Est une maladie rapidement mortelle avant 3 mois", "B. Peut être secondaire à une non-ségrégation chromosomique", "C. Associe un hypotélorisme et un œil en cyclope", "D. A un risque de survenue indépendant de l'âge maternel", "E. Se caractérise par la griffe digitale"], ans: ["A","B","C"] },
      { q: "La trisomie 13 est une maladie :", opts: ["A. Dont le risque d'apparition augmente avec l'âge paternel", "B. Dont le risque d'apparition augmente avec l'âge maternel", "C. Connue aussi sous le nom du syndrome de Down", "D. Connue aussi sous le nom du syndrome de Patau", "E. Connue aussi sous le nom du syndrome d'Edward"], ans: ["B","D"] },
      { q: "Les malformations viscérales rencontrées dans la trisomie 13 sont :", opts: ["A. L'holoproencéphalie", "B. La fente labio-palatine", "C. La griffe digitale", "D. Les pieds en piolet", "E. L'hexadactylie"], ans: ["A","B","E"] },
      { q: "Les signes cliniques de la trisomie 13 sont :", opts: ["A. La griffe digitale", "B. La fente labio-palatine", "C. L'œil en cyclope", "D. L'hexadactylie", "E. Les pieds en piolet"], ans: ["B","C","D"] },
      { q: "À propos de la trisomie 13, quelles sont les propositions justes ?", opts: ["A. Le risque de récurrence est de 1% chez des parents ayant déjà un enfant trisomique 13", "B. Son risque de récurrence est très augmenté", "C. Le tableau clinique comporte un syndrome malformatif léger", "D. 90% des enfants atteints de trisomie 13 décèdent vers l'âge de 6 mois", "E. Son risque augmente avec l'âge maternel"], ans: ["A","E"] },
      { q: "À propos de la trisomie 13, quelles sont les propositions justes ?", opts: ["A. Le caryotype des parents doit être réalisé quel que soit la formule chromosomique de l'enfant trisomique 13", "B. Le tableau clinique inclut un syndrome dysmorphique et malformatif grave", "C. 90% des fœtus atteints de trisomie 13 décèdent in utero", "D. Son risque augmente avec l'âge maternel", "E. Son risque de récurrence est très augmenté"], ans: ["B","C","D"] },
    ]
  },
  {
    id: "t18", label: "Trisomie 18", accent: "#534AB7", light: "#EEEDFE", border: "#AFA9EC",
    questions: [
      { q: "La trisomie 18 en mosaïque :", opts: ["A. Peut résulter d'une réduction d'une trisomie 18 présente au stade zygotique", "B. Peut résulter d'un accident mitotique post-zygotique tardif", "C. Peut résulter d'une anomalie de ségrégation des chromosomes par non-disjonction méiotique", "D. Est d'évolution toujours mortelle", "E. Est responsable d'une stérilité chez les garçons"], ans: ["A","B"] },
      { q: "Dans la trisomie 18 libre et homogène :", opts: ["A. Le risque de récurrence est de 1%", "B. La dolichocéphalie nécessite un traitement chirurgical", "C. La non-ségrégation des chromosomes 18 est liée à l'âge maternel", "D. La griffe digitale est fréquente", "E. Les fentes labiales et palatines sont rares"], ans: ["A","C","D"] },
      { q: "Dans la trisomie 18 :", opts: ["A. La majorité des enfants décèdent avant 1 an", "B. Le bassin est étroit", "C. Le cou est court", "D. Les malformations cardiaques sont rares", "E. La prise en charge médicale est limitée aux soins de support et de confort"], ans: ["A","B","C","E"] },
      { q: "La trisomie 18 de novo peut résulter :", opts: ["A. D'une non-disjonction mitotique", "B. D'une non-disjonction de la division méiotique réductionnelle", "C. D'un accident de la fécondation", "D. D'une non-disjonction de la division méiotique équationnelle", "E. D'un parent porteur d'une anomalie de structure équilibrée"], ans: ["B","D"] },
      { q: "(Cas clinique – femme 30 ans, 14 SA) Quelles anomalies morphologiques peuvent être retrouvées à l'échographie ?", opts: ["A. Un retard de croissance intra-utérin", "B. Un nez petit et pointu", "C. Un prognathisme", "D. Une fente labiale et palatine", "E. Des pieds varus équin"], ans: ["A","B","D","E"] },
      { q: "Les anomalies des mains retrouvées dans la trisomie 18 sont :", opts: ["A. Les poings fermés", "B. Le chevauchement du 2ème doigt sur le 3ème doigt", "C. Le chevauchement du 5ème doigt sur le 4ème doigt", "D. La clinodactylie du 5ème doigt", "E. La clinodactylie du 2ème doigt"], ans: ["A","B","C"] },
      { q: "Les signes de dysmorphie peuvent être présents dans la trisomie 18 SAUF un, lequel ?", opts: ["A. Une micrognatie", "B. Un bassin large", "C. Des oreilles faunesques", "D. Une fente labiale", "E. Une griffe digitale"], ans: ["B"] },
      { q: "Dans la trisomie 18 :", opts: ["A. Les filles sont plus touchées que les garçons", "B. 90% des enfants décèdent avant 1 an", "C. La prise en charge médicale est limitée aux soins de support et de confort", "D. Le traitement chirurgical des malformations modifie le pronostic", "E. La forme en mosaïque est la plus fréquente"], ans: ["A","B","C"] },
      { q: "À propos de la trisomie 18, quelles sont les propositions justes ?", opts: ["A. Le tableau clinique inclut un syndrome dysmorphique et un syndrome malformatif", "B. La survie moyenne est au-delà de 10 ans", "C. Dans 80% des cas la trisomie 18 est libre et homogène", "D. Le signe clinique pathognomonique est la présence d'un nez en casque de guerrier grec", "E. La présence de griffe digitale"], ans: ["A","C","E"] },
      { q: "À propos de la trisomie 18, quelles sont les propositions justes ?", opts: ["A. Les malformations viscérales sont rares", "B. Le tableau clinique inclut une dolichocéphalie et un cou court", "C. La moyenne de survie est supérieure à 10 ans", "D. Dans 80% des cas la trisomie 18 est libre et homogène", "E. Le signe clinique pathognomonique est la présence de la griffe digitale"], ans: ["B","D","E"] },
      { q: "Les signes de dysmorphie peuvent être présents dans la trisomie 18 SAUF un, lequel ?", opts: ["A. Une dolichocéphalie", "B. Une micrognatie", "C. Des oreilles faunesques", "D. Une nuque aplatie avec excès de peau", "E. Une griffe digitale"], ans: ["D"] },
      { q: "(Cas clinique – dolichocéphalie, fente labiale bilatérale, griffe digitale) Quel est le diagnostic le plus probable ?", opts: ["A. Le syndrome de Down", "B. Le syndrome de Patau", "C. Le syndrome de Wolf-Hirschhorn", "D. Le syndrome de cri du chat", "E. Le syndrome d'Edwards"], ans: ["E"] },
      { q: "Quelle pourrait être la formule chromosomique de ce fœtus (syndrome d'Edwards) ?", opts: ["A. 46XX+18", "B. 47XX+18", "C. 46XX+13", "D. 47XX+13", "E. 47 XXX"], ans: ["B"] },
      { q: "Une interruption thérapeutique de grossesse a été refusée. Après la naissance, quelle est l'espérance de vie de ce fœtus ?", opts: ["A. Supérieure à 5 ans", "B. Supérieure à 10 ans", "C. Supérieure à 20 ans", "D. Supérieure à 6 mois", "E. Inférieure à 6 mois"], ans: ["E"] },
      { q: "(Cas clinique – nourrisson sexe féminin, trisomie 18) Quels sont les signes de dysmorphie faciale ?", opts: ["A. La dolichocéphalie", "B. Une micrognatie", "C. Une Brachymésophalangie du 5ème doigt", "D. Une nuque aplatie avec excès de peau", "E. Un pli palmaire unique"], ans: ["A","B","E"] },
      { q: "Quels sont les anomalies de membres caractéristiques de la trisomie 18 ?", opts: ["A. L'attitude du suppliant", "B. Les poings fermés", "C. La griffe digitale", "D. Les pieds en piolet", "E. L'hyper laxité ligamentaire"], ans: ["A","B","C","D"] },
      { q: "Quelle est la formule chromosomique la plus fréquente dans la trisomie 18 ?", opts: ["A. 46XX/47XX+18", "B. 46XXt(14;18)", "C. 46XXt(18;21)", "D. 47XY+18", "E. 47XX+18"], ans: ["E"] },
      { q: "L'évolution de ce nouveau-né (trisomie 18) sera :", opts: ["A. Mortelle avant 6 mois", "B. Mortelle après 12 mois", "C. L'amélioration de la dysmorphie", "D. L'apparition d'une déficience mentale à 3 ans", "E. L'apparition des troubles du comportement alimentaire à 2 ans"], ans: ["A"] },
      { q: "(Cas clinique – nourrisson Mouna, 2 mois, dolichocéphalie, oreilles faunesques, griffe digitale) Quel est votre diagnostic ?", opts: ["A. Le syndrome de Down", "B. Le syndrome d'Edwards", "C. Le syndrome de Patau", "D. Le syndrome de Wolf-Hirschhorn", "E. Le syndrome de cri du chat"], ans: ["B"] },
      { q: "Quelle pourrait être la formule chromosomique de ce nourrisson (Mouna) ?", opts: ["A. 46XX+18", "B. 46XX+13", "C. 47XX+13", "D. 47XX+18", "E. 47 XXX"], ans: ["D"] },
      { q: "L'espérance de vie de ce nourrisson (Mouna) est :", opts: ["A. Supérieure à 5 ans", "B. Supérieure à 10 ans", "C. Supérieure à 20 ans", "D. Inférieure à 3 mois", "E. Inférieure à 6 mois"], ans: ["E"] },
      { q: "À propos de la trisomie 18, quelles sont les propositions justes ?", opts: ["A. Le caryotype des parents doit être réalisé quel que soit la formule chromosomique de l'enfant trisomique 18", "B. Le tableau clinique inclut un syndrome dysmorphique et un syndrome malformatif", "C. La trisomie 18 est caractérisée par une moyenne de survie au-delà de 10 ans", "D. Dans 80% des cas la trisomie 18 est libre et homogène", "E. Le signe clinique pathognomonique est la présence d'un nez en casque de guerrier grec"], ans: ["B","D"] },
      { q: "(Cas clinique – RCIU, fente labiale et palatine, griffe digitale) Quel diagnostic suspectez-vous ?", opts: ["A. Trisomie 13", "B. Trisomie 18", "C. Trisomie 21", "D. Le syndrome de Wolf-Hirschhorn", "E. Le syndrome de cri de chat"], ans: ["B"] },
    ]
  }
];

const LETTER = ["A","B","C","D","E"];

export default function App() {
  const [activeTab, setActiveTab] = useState("t21");
  const [selections, setSelections] = useState({});
  const [checked, setChecked] = useState({});

  const topic = TOPICS.find(t => t.id === activeTab);
  const { accent, light, border } = topic;

  function qKey(topicId, qi) { return `${topicId}-${qi}`; }

  function toggle(topicId, qi, letter) {
    const key = qKey(topicId, qi);
    setSelections(prev => {
      const cur = prev[key] || [];
      return { ...prev, [key]: cur.includes(letter) ? cur.filter(l => l !== letter) : [...cur, letter] };
    });
  }

  function verify(topicId, qi) {
    setChecked(prev => ({ ...prev, [qKey(topicId, qi)]: true }));
  }

  function reset(topicId, qi) {
    const key = qKey(topicId, qi);
    setSelections(prev => { const n = { ...prev }; delete n[key]; return n; });
    setChecked(prev => { const n = { ...prev }; delete n[key]; return n; });
  }

  function getStatus(topicId, qi) {
    const key = qKey(topicId, qi);
    if (!checked[key]) return null;
    const sel = selections[key] || [];
    const ans = topic.questions[qi].ans;
    return sel.length === ans.length && ans.every(a => sel.includes(a)) ? "correct" : "wrong";
  }

  const total = topic.questions.length;
  const done = topic.questions.filter((_, i) => checked[qKey(activeTab, i)]).length;
  const correct = topic.questions.filter((_, i) => getStatus(activeTab, i) === "correct").length;

  return (
    <div style={{ fontFamily: "var(--font-sans)", maxWidth: 720, margin: "0 auto", padding: "0 0 2rem" }}>
      <div style={{ padding: "1.5rem 0 0.5rem", borderBottom: `2px solid ${border}`, marginBottom: "1rem" }}>
        <div style={{ fontSize: 11, fontWeight: 500, letterSpacing: "0.08em", color: "var(--color-text-secondary)", textTransform: "uppercase", marginBottom: 6 }}>Génétique Médicale — QCM Interactif</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {TOPICS.map(t => (
            <button key={t.id} onClick={() => setActiveTab(t.id)}
              style={{ padding: "7px 16px", borderRadius: 20, fontSize: 13, fontWeight: 500, cursor: "pointer", border: `1.5px solid ${t.border}`,
                background: activeTab === t.id ? t.accent : "transparent",
                color: activeTab === t.id ? "#fff" : t.accent, transition: "all 0.15s" }}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div style={{ display: "flex", gap: 12, margin: "0.75rem 0 1.25rem", flexWrap: "wrap" }}>
        {[["Questions", total], ["Vérifiées", done], ["Correctes", correct]].map(([label, val]) => (
          <div key={label} style={{ flex: 1, minWidth: 100, background: "var(--color-background-secondary)", borderRadius: "var(--border-radius-md)", padding: "10px 14px" }}>
            <div style={{ fontSize: 11, color: "var(--color-text-secondary)", fontWeight: 500, marginBottom: 2 }}>{label}</div>
            <div style={{ fontSize: 22, fontWeight: 500, color: label === "Correctes" && done > 0 ? accent : "var(--color-text-primary)" }}>{val}</div>
          </div>
        ))}
        <div style={{ flex: 1, minWidth: 100, background: "var(--color-background-secondary)", borderRadius: "var(--border-radius-md)", padding: "10px 14px" }}>
          <div style={{ fontSize: 11, color: "var(--color-text-secondary)", fontWeight: 500, marginBottom: 2 }}>Score</div>
          <div style={{ fontSize: 22, fontWeight: 500, color: accent }}>{done > 0 ? Math.round(correct / done * 100) : 0}%</div>
        </div>
      </div>

      {topic.questions.map((q, qi) => {
        const key = qKey(activeTab, qi);
        const sel = selections[key] || [];
        const isChecked = !!checked[key];
        const status = getStatus(activeTab, qi);

        return (
          <div key={qi} style={{ background: "var(--color-background-primary)", border: `0.5px solid ${isChecked ? (status === "correct" ? "#1D9E75" : "#D85A30") : "var(--color-border-tertiary)"}`,
            borderRadius: "var(--border-radius-lg)", padding: "1rem 1.25rem", marginBottom: 12 }}>
            <div style={{ display: "flex", gap: 10, marginBottom: 10, alignItems: "flex-start" }}>
              <span style={{ minWidth: 28, height: 28, borderRadius: "50%", background: light, display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 12, fontWeight: 500, color: accent, flexShrink: 0 }}>{qi + 1}</span>
              <p style={{ margin: 0, fontSize: 14, fontWeight: 500, color: "var(--color-text-primary)", lineHeight: 1.5 }}>{q.q}</p>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 12, paddingLeft: 38 }}>
              {q.opts.map((opt, oi) => {
                const letter = LETTER[oi];
                const selected = sel.includes(letter);
                const isCorrectOpt = q.ans.includes(letter);

                let bg = "transparent", borderCol = "var(--color-border-tertiary)", textCol = "var(--color-text-primary)";
                if (isChecked) {
                  if (isCorrectOpt) { bg = "rgba(29,158,117,0.1)"; borderCol = "#1D9E75"; textCol = "#085041"; }
                  else if (selected && !isCorrectOpt) { bg = "rgba(216,90,48,0.1)"; borderCol = "#D85A30"; textCol = "#4A1B0C"; }
                } else if (selected) {
                  bg = light; borderCol = accent; textCol = accent;
                }

                return (
                  <div key={oi} onClick={() => !isChecked && toggle(activeTab, qi, letter)}
                    style={{ display: "flex", alignItems: "flex-start", gap: 8, padding: "7px 10px", borderRadius: "var(--border-radius-md)",
                      border: `0.5px solid ${borderCol}`, background: bg, cursor: isChecked ? "default" : "pointer",
                      transition: "all 0.1s", userSelect: "none" }}>
                    <div style={{ width: 16, height: 16, borderRadius: 4, border: `1.5px solid ${borderCol}`, flexShrink: 0, marginTop: 1,
                      background: selected ? accent : "transparent", display: "flex", alignItems: "center", justifyContent: "center" }}>
                      {selected && <svg width="10" height="10" viewBox="0 0 10 10"><polyline points="1.5,5 4,7.5 8.5,2" fill="none" stroke="#fff" strokeWidth="1.5" strokeLinecap="round"/></svg>}
                      {isChecked && isCorrectOpt && !selected && <svg width="10" height="10" viewBox="0 0 10 10"><polyline points="1.5,5 4,7.5 8.5,2" fill="none" stroke="#1D9E75" strokeWidth="1.5" strokeLinecap="round"/></svg>}
                    </div>
                    <span style={{ fontSize: 13, color: textCol, lineHeight: 1.4 }}>{opt}</span>
                  </div>
                );
              })}
            </div>

            <div style={{ paddingLeft: 38, display: "flex", gap: 8, alignItems: "center" }}>
              {!isChecked ? (
                <button onClick={() => verify(activeTab, qi)}
                  style={{ padding: "6px 16px", borderRadius: 20, fontSize: 12, fontWeight: 500, cursor: sel.length === 0 ? "not-allowed" : "pointer",
                    border: `1px solid ${accent}`, background: sel.length === 0 ? "transparent" : accent,
                    color: sel.length === 0 ? accent : "#fff", opacity: sel.length === 0 ? 0.5 : 1, transition: "all 0.15s" }}>
                  Vérifier
                </button>
              ) : (
                <>
                  <span style={{ fontSize: 12, fontWeight: 500, color: status === "correct" ? "#0F6E56" : "#993C1D",
                    background: status === "correct" ? "#E1F5EE" : "#FAECE7", padding: "4px 10px", borderRadius: 12 }}>
                    {status === "correct" ? "✓ Correct" : "✗ Incorrect"}
                  </span>
                  <button onClick={() => reset(activeTab, qi)}
                    style={{ padding: "4px 12px", borderRadius: 12, fontSize: 12, cursor: "pointer",
                      border: "0.5px solid var(--color-border-secondary)", background: "transparent", color: "var(--color-text-secondary)" }}>
                    Réessayer
                  </button>
                </>
              )}
              {isChecked && status !== "correct" && (
                <span style={{ fontSize: 11, color: "var(--color-text-secondary)" }}>
                  Réponse(s) : {q.ans.join(", ")}
                </span>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
